package com.big0soft.testdeploy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestDeployApplicationTests {

	@Test
	void contextLoads() {
	}

}
